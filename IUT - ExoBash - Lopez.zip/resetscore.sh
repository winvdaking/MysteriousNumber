#!/bin/bash
# Mysterious Number Leaderboard
echo > scoreboard.txt